///**
// * 
// */
//package com.onlineExamination.repository;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.jpa.repository.Query;
//import org.springframework.stereotype.Repository;
//
//import com.onlineExamination.Entity.ExamQuestions;
//import com.onlineExamination.Entity.StudentExamQuestions;
//
//
///**
// * @author Lenovo
// *
// */
//@Repository
//public interface StudentExamQuestionsRepo extends JpaRepository<StudentExamQuestions, Long> {
//
//	//public StudentExamQuestions findByStuexamquesid(long stuexamquesid);
//	
//	
//}
