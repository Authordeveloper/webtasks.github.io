/**
 * 
 */
package com.onlineExamination.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author Lenovo
 *
 */
@Entity
@Table(name = "tblquestionsoptions")
public class ExamQuestionsOptions {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long qouid;
	
	private long quid;
	private long qoid;
	private String optionValue;
	private boolean isCorrectOption;
	private long mapOptionId;
	/**
	 * @return the qouid
	 */
	public long getQouid() {
		return qouid;
	}
	/**
	 * @param qouid the qouid to set
	 */
	public void setQouid(long qouid) {
		this.qouid = qouid;
	}
	/**
	 * @return the quid
	 */
	public long getQuid() {
		return quid;
	}
	/**
	 * @param quid the quid to set
	 */
	public void setQuid(long quid) {
		this.quid = quid;
	}
	/**
	 * @return the qoid
	 */
	public long getQoid() {
		return qoid;
	}
	/**
	 * @param qoid the qoid to set
	 */
	public void setQoid(long qoid) {
		this.qoid = qoid;
	}
	/**
	 * @return the optionValue
	 */
	public String getOptionValue() {
		return optionValue;
	}
	/**
	 * @param optionValue the optionValue to set
	 */
	public void setOptionValue(String optionValue) {
		this.optionValue = optionValue;
	}
	/**
	 * @return the isCorrectOption
	 */
	public boolean isCorrectOption() {
		return isCorrectOption;
	}
	/**
	 * @param isCorrectOption the isCorrectOption to set
	 */
	public void setCorrectOption(boolean isCorrectOption) {
		this.isCorrectOption = isCorrectOption;
	}
	/**
	 * @return the mapOptionId
	 */
	public long getMapOptionId() {
		return mapOptionId;
	}
	/**
	 * @param mapOptionId the mapOptionId to set
	 */
	public void setMapOptionId(long mapOptionId) {
		this.mapOptionId = mapOptionId;
	}
	@Override
	public String toString() {
		return "ExamQuestionsOptions [qouid=" + qouid + ", quid=" + quid + ", qoid=" + qoid + ", optionValue="
				+ optionValue + ", isCorrectOption=" + isCorrectOption + ", mapOptionId=" + mapOptionId + "]";
	}
	
	
 
	

}
