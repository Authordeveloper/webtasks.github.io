/**
 * 
 */
package com.onlineExamination.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author Lenovo
 *
 */
@Entity
@Table(name = "student_exam_schedule")
public class StudentExamSchedule {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	long studentScheduleId;
	
	long examScheduleId;
	String CandidateId;
	String examStartTime;
	String examEndTIme;
	
	
	
	@Override
	public String toString() {
		return "StudentExamSchedule [studentScheduleId=" + studentScheduleId + ", examScheduleId=" + examScheduleId
				+ ", CandidateId=" + CandidateId + ", examStartTime=" + examStartTime + ", examEndTIme=" + examEndTIme
				+ "]";
	}



	/**
	 * @return the studentScheduleId
	 */
	public long getStudentScheduleId() {
		return studentScheduleId;
	}



	/**
	 * @param studentScheduleId the studentScheduleId to set
	 */
	public void setStudentScheduleId(long studentScheduleId) {
		this.studentScheduleId = studentScheduleId;
	}



	/**
	 * @return the examScheduleId
	 */
	public long getExamScheduleId() {
		return examScheduleId;
	}



	/**
	 * @param examScheduleId the examScheduleId to set
	 */
	public void setExamScheduleId(long examScheduleId) {
		this.examScheduleId = examScheduleId;
	}



	/**
	 * @return the candidateId
	 */
	public String getCandidateId() {
		return CandidateId;
	}



	/**
	 * @param candidateId the candidateId to set
	 */
	public void setCandidateId(String candidateId) {
		CandidateId = candidateId;
	}



	/**
	 * @return the examStartTime
	 */
	public String getExamStartTime() {
		return examStartTime;
	}



	/**
	 * @param examStartTime the examStartTime to set
	 */
	public void setExamStartTime(String examStartTime) {
		this.examStartTime = examStartTime;
	}



	/**
	 * @return the examEndTIme
	 */
	public String getExamEndTIme() {
		return examEndTIme;
	}



	/**
	 * @param examEndTIme the examEndTIme to set
	 */
	public void setExamEndTIme(String examEndTIme) {
		this.examEndTIme = examEndTIme;
	}



	/**
	 * 
	 */
	public StudentExamSchedule() {
		// TODO Auto-generated constructor stub
	}

}
