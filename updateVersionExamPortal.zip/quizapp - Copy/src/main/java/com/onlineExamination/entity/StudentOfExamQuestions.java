/**
 * 
 */
package com.onlineExamination.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author Lenovo
 *
 */
@Entity
@Table(name = "stdntExamQuestions")
public class StudentOfExamQuestions {
	
	@Id
	@GeneratedValue(generator = "student_gen",strategy = GenerationType.AUTO)	
	private long studentId;
	
	private String examScheduleId;
	private String selectedOption;
	private String correctOption;
	private String statusOption;
	private String questionCode;
	private String condidateId;
	/**
	 * @return the studentId
	 */
	public long getStudentId() {
		return studentId;
	}
	/**
	 * @param studentId the studentId to set
	 */
	public void setStudentId(long studentId) {
		this.studentId = studentId;
	}
	/**
	 * @return the examScheduleId
	 */
	public String getExamScheduleId() {
		return examScheduleId;
	}
	/**
	 * @param examScheduleId the examScheduleId to set
	 */
	public void setExamScheduleId(String examScheduleId) {
		this.examScheduleId = examScheduleId;
	}
	/**
	 * @return the selectedOption
	 */
	public String getSelectedOption() {
		return selectedOption;
	}
	/**
	 * @param selectedOption the selectedOption to set
	 */
	public void setSelectedOption(String selectedOption) {
		this.selectedOption = selectedOption;
	}
	/**
	 * @return the correctOption
	 */
	public String getCorrectOption() {
		return correctOption;
	}
	/**
	 * @param correctOption the correctOption to set
	 */
	public void setCorrectOption(String correctOption) {
		this.correctOption = correctOption;
	}
	/**
	 * @return the statusOption
	 */
	public String getStatusOption() {
		return statusOption;
	}
	/**
	 * @param statusOption the statusOption to set
	 */
	public void setStatusOption(String statusOption) {
		this.statusOption = statusOption;
	}
	/**
	 * @return the questionCode
	 */
	public String getQuestionCode() {
		return questionCode;
	}
	/**
	 * @param questionCode the questionCode to set
	 */
	public void setQuestionCode(String questionCode) {
		this.questionCode = questionCode;
	}
	/**
	 * @return the condidateId
	 */
	public String getCondidateId() {
		return condidateId;
	}
	/**
	 * @param condidateId the condidateId to set
	 */
	public void setCondidateId(String condidateId) {
		this.condidateId = condidateId;
	}
	@Override
	public String toString() {
		return "StudentOfExamQuestions [studentId=" + studentId + ", examScheduleId=" + examScheduleId
				+ ", selectedOption=" + selectedOption + ", correctOption=" + correctOption + ", statusOption="
				+ statusOption + ", questionCode=" + questionCode + ", condidateId=" + condidateId + "]";
	}
	/**
	 * @param studentId
	 * @param examScheduleId
	 * @param selectedOption
	 * @param correctOption
	 * @param statusOption
	 * @param questionCode
	 * @param condidateId
	 */
	public StudentOfExamQuestions(long studentId, String examScheduleId, String selectedOption, String correctOption,
			String statusOption, String questionCode, String condidateId) {
		super();
		this.studentId = studentId;
		this.examScheduleId = examScheduleId;
		this.selectedOption = selectedOption;
		this.correctOption = correctOption;
		this.statusOption = statusOption;
		this.questionCode = questionCode;
		this.condidateId = condidateId;
	}
	/**
	 * 
	 */
	public StudentOfExamQuestions() {
		super();
	}
	
	
	

}
