/**
 * 
 */
package com.onlineExamination.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author Lenovo
 *
 */
@Entity
@Table(name = "tblquestions")
public class ExamQuestions {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long quid;
	
	private String Question;
	private String option1;
	private String option2;  
	private String option3;
	private String option4;
	private String CorrectOption;
	private String chrCourseCode;
	private String chrQuestType;
	private String chrImagePath;
	
	/**
	 * @return the qID
	 */
	public long getQuid() {
		return quid;
	}
	/**
	 * @param qID the qID to set
	 */
	public void setQuid(int Quid) {
		quid = Quid;
	}
	/**
	 * @return the question
	 */
	public String getQuestion() {
		return Question;
	}
	/**
	 * @param question the question to set
	 */
	
	public void setQuestion(String question) {
		Question = question;
	}
	/**
	 * @return the option1
	 */
	public String getOption1() {
		return option1;
	}
	/**
	 * @param option1 the option1 to set
	 */
	public void setOption1(String option1) {
		this.option1 = option1;
	}
	/**
	 * @return the option2
	 */
	public String getOption2() {
		return option2;
	}
	/**
	 * @param option2 the option2 to set
	 */
	public void setOption2(String option2) {
		this.option2 = option2;
	}
	/**
	 * @return the option3
	 */
	public String getOption3() {
		return option3;
	}
	/**
	 * @param option3 the option3 to set
	 */
	public void setOption3(String option3) {
		this.option3 = option3;
	}
	/**
	 * @return the option4
	 */
	public String getOption4() {
		return option4;
	}
	/**
	 * @param option4 the option4 to set
	 */
	public void setOption4(String option4) {
		this.option4 = option4;
	}
	/**
	 * @return the correctOption
	 */
	public String getCorrectOption() {
		return CorrectOption;
	}
	/**
	 * @param correctOption the correctOption to set
	 */
	public void setCorrectOption(String correctOption) {
		CorrectOption = correctOption;
	}
	/**
	 * @return the chrCourseCode
	 */
	public String getChrCourseCode() {
		return chrCourseCode;
	}
	/**
	 * @param chrCourseCode the chrCourseCode to set
	 */
	public void setChrCourseCode(String chrCourseCode) {
		this.chrCourseCode = chrCourseCode;
	}
	/**
	 * @return the chrQuestType
	 */
	public String getChrQuestType() {
		return chrQuestType;
	}
	/**
	 * @param chrQuestType the chrQuestType to set
	 */
	public void setChrQuestType(String chrQuestType) {
		this.chrQuestType = chrQuestType;
	}
	/**
	 * @return the chrImagePath
	 */
	public String getChrImagePath() {
		return chrImagePath;
	}
	/**
	 * @param chrImagePath the chrImagePath to set
	 */
	public void setChrImagePath(String chrImagePath) {
		this.chrImagePath = chrImagePath;
	}
	@Override
	public String toString() {
		return "ExamQuestions [QID=" + quid + ", Question=" + Question + ", option1=" + option1 + ", option2=" + option2
				+ ", option3=" + option3 + ", option4=" + option4 + ", CorrectOption=" + CorrectOption
				+ ", chrCourseCode=" + chrCourseCode + ", chrQuestType=" + chrQuestType + ", chrImagePath="
				+ chrImagePath + "]";
	}
	/**
	 * @param question
	 * @param option1
	 * @param option2
	 * @param option3
	 * @param option4
	 * @param correctOption
	 * @param chrCourseCode
	 * @param chrQuestType
	 * @param chrImagePath
	 */
	public ExamQuestions(String question, String option1, String option2, String option3, String option4,
			String correctOption, String chrCourseCode, String chrQuestType, String chrImagePath) {
		super();
		Question = question;
		this.option1 = option1;
		this.option2 = option2;
		this.option3 = option3;
		this.option4 = option4;
		CorrectOption = correctOption;
		this.chrCourseCode = chrCourseCode;
		this.chrQuestType = chrQuestType;
		this.chrImagePath = chrImagePath;
	}
	/**
	 * 
	 */
	public ExamQuestions() {
		super();
	}
	
 
	

}
