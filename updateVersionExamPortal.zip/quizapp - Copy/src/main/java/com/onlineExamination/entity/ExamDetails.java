/**
 * 
 */
package com.onlineExamination.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author Lenovo
 *
 */
@Entity
@Table(name = "examdetails")
public class ExamDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long examDetailsId;
	
	private String Description;
	private String totalquestions;
	private String wrongmarks;
	private String correctmarks;
	private String endTime;
	private String startTime;
	private String examduration;
	private String candidateId;
	private String subjectName;
	private String dates;
	
	
	/**
	 * @return the dates
	 */
	public String getDates() {
		return dates;
	}
	/**
	 * @param dates the dates to set
	 */
	public void setDates(String dates) {
		this.dates = dates;
	}
	/**
	 * @return the examDetailsId
	 */
	
	public long getExamDetailsId() {
		return examDetailsId;
	}
	/**
	 * @return the subjectName
	 */
	public String getSubjectName() {
		return subjectName;
	}
	/**
	 * @param subjectName the subjectName to set
	 */
	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}
	/**
	 * @param examDetailsId the examDetailsId to set
	 */
	public void setExamDetailsId(long examDetailsId) {
		this.examDetailsId = examDetailsId;
	}
	/**
	 * @return the candidateId
	 */
	public String getCandidateId() {
		return candidateId;
	}
	/**
	 * @param candidateId the candidateId to set
	 */
	public void setCandidateId(String candidateId) {
		this.candidateId = candidateId;
	}
	/**
	 * @param examDetailsId the examDetailsId to set
	 */
	public void setExamDetailsId(int examDetailsId) {
		this.examDetailsId = examDetailsId;
	}
	/**
	 * @return the description
	 */
	public String getDescription() {
		return Description;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		Description = description;
	}
	/**
	 * @return the totalquestions
	 */
	public String getTotalquestions() {
		return totalquestions;
	}
	/**
	 * @param totalquestions the totalquestions to set
	 */
	public void setTotalquestions(String totalquestions) {
		this.totalquestions = totalquestions;
	}
	/**
	 * @return the wrongmarks
	 */
	public String getWrongmarks() {
		return wrongmarks;
	}
	/**
	 * @param wrongmarks the wrongmarks to set
	 */
	public void setWrongmarks(String wrongmarks) {
		this.wrongmarks = wrongmarks;
	}
	/**
	 * @return the correctmarks
	 */
	public String getCorrectmarks() {
		return correctmarks;
	}
	/**
	 * @param correctmarks the correctmarks to set
	 */
	public void setCorrectmarks(String correctmarks) {
		this.correctmarks = correctmarks;
	}
	/**
	 * @return the enddate
 
	/**
	 * @return the examduration
	 */
	public String getExamduration() {
		return examduration;
	}
	/**
	 * @return the endTime
	 */
	public String getEndTime() {
		return endTime;
	}
	/**
	 * @param endTime the endTime to set
	 */
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	/**
	 * @return the startTime
	 */
	public String getStartTime() {
		return startTime;
	}
	/**
	 * @param startTime the startTime to set
	 */
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	/**
	 * @param examduration the examduration to set
	 */
	public void setExamduration(String examduration) {
		this.examduration = examduration;
	}
	/**
	 * @param examDetailsId
	 * @param description
	 * @param totalquestions
	 * @param wrongmarks
	 * @param correctmarks
	 * @param enddate
	 * @param startdate
	 * @param examduration
	 */
	@Override
	public String toString() {
		return "ExamDetails [examDetailsId=" + examDetailsId + ", Description=" + Description + ", totalquestions="
				+ totalquestions + ", wrongmarks=" + wrongmarks + ", correctmarks=" + correctmarks + ", endTime="
				+ endTime + ", startTime=" + startTime + ", examduration=" + examduration + ", candidateId="
				+ candidateId + "]";
	}
	/**
	 * @param examDetailsId
	 * @param description
	 * @param totalquestions
	 * @param wrongmarks
	 * @param correctmarks
	 * @param endTime
	 * @param startTime
	 * @param examduration
	 * @param candidateId
	 */
	
	/**
	 * 
	 */
	public ExamDetails() {
	}
	public ExamDetails(long examDetailsId, String description, String totalquestions, String wrongmarks,
			String correctmarks, String endTime, String startTime, String examduration, String candidateId,
			String subjectName, String dates) {
		super();
		this.examDetailsId = examDetailsId;
		Description = description;
		this.totalquestions = totalquestions;
		this.wrongmarks = wrongmarks;
		this.correctmarks = correctmarks;
		this.endTime = endTime;
		this.startTime = startTime;
		this.examduration = examduration;
		this.candidateId = candidateId;
		this.subjectName = subjectName;
		this.dates = dates;
	}
 
	/**
	 * 
	 */
	         
	
	
	

}
