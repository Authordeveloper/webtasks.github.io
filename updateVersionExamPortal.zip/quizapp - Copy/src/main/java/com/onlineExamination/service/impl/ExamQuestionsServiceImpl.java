/**
 * 
 */
package com.onlineExamination.service.impl;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.onlineExamination.entity.ExamQuestions;
import com.onlineExamination.repository.ExamQuestionsRepo;
import com.onlineExamination.service.ExamQuestionsService;


/**
 * @author Lenovo
 *
 */
@Service
public class ExamQuestionsServiceImpl implements ExamQuestionsService{

	@Autowired
	ExamQuestionsRepo examQuestionsRepo;
	
	
	//List<Integer> list = new ArrayList<>();
	 
	List<Integer> listNonRepeatQuid = new ArrayList<>();
	
	@Override
	public ExamQuestions getQuestions(String subjectName) {
		// TODO Auto-generated method stub
//		System.out.println("subjectName   impl  :"+subjectName);
	     List<ExamQuestions>  quesList = examQuestionsRepo.findByChrCourseCode(subjectName);
//	     System.out.println("subjectName   impl list generating   :"+quesList );
		int min = 1;
		int max = quesList.size() - 1;
		int quidd = (int) (Math.random() * (max + 1 - min) + min);
	 
//		ExamQuestions examQuestionss = examQuestionsRepo.getQuestionsByRandom(quidd); 
		//not return same questions id 
		int questionLimitition = 8;
	     
	//	System.out.println("Value printed here :"+quid);
		
//		System.out.println("Value printed here :"+listNonRepeatQuid.toString());
		
		
		for (int i = 0; listNonRepeatQuid.size() < questionLimitition; i++) {
			
			int quid = (int) (Math.random() * (max + 1 - min) + min);
			
			if(!(listNonRepeatQuid.contains(quid))) { 
				
				ExamQuestions examQuestions =	quesList.get(quid);
				
				//ExamQuestions examQuestions = examQuestionsRepo.getQuestionsByRandom(quid); 
				
				listNonRepeatQuid.add(quid);
				
//				System.out.println("print value for the data "+listNonRepeatQuid.toString());

				return examQuestions;
		
			} else {
				
			}
		}
		return null; 
		 
		
	
	}

	@Override
	public ExamQuestions getCorrectValueOfDB(long quesId) {
		// TODO Auto-generated method stub
		
		
		return examQuestionsRepo.findCorrectOptionByQuid(quesId);
	}

	@Override
	public List<ExamQuestions> getAllQuestions() {
		// TODO Auto-generated method stub
		return examQuestionsRepo.getAllQuestions();
	}

	@Override
	public ExamQuestions saveExamQuestions(ExamQuestions eq) {
		
		ExamQuestions examQuestions = new ExamQuestions(eq.getQuestion(),eq.getOption1(),eq.getOption2(),eq.getOption3(),eq.getOption4(),eq.getCorrectOption(),
				eq.getChrCourseCode(),eq.getChrQuestType(),eq.getChrImagePath()
				);
		
		
		return examQuestionsRepo.save(examQuestions);
	}


 

	
}
