///**
// * 
// */
//package com.onlineExamination.service.impl;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.onlineExamination.Entity.StudentExamQuestions;
//import com.onlineExamination.repository.StudentExamQuestionsRepo;
//import com.onlineExamination.service.StudentExamQuestionsService;
//
///**
// * @author Lenovo
// *
// */
//@Service
//public class StudentExamQuestionsServiceImpl  implements StudentExamQuestionsService{
//
// 
//	
//	 
//
//}
